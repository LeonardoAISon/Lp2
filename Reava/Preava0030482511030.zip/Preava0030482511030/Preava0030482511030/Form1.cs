﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Preava0030482511030
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            string[] posicao = new string[10];
            float[] valorInicial = new float[10];
            float[] valorFinal = new float[10];
            

            for (int i = 0; i < 10; i++)
            {
                valorInicial[i] = rnd.Next(1, 10);


                if (valorInicial[i] % 2 != 0)
                    {
                        valorFinal[i] = valorInicial[i] + 4;
                    }
                    else
                    {
                        valorFinal[i] = valorInicial[i] * 4;
                    }
                

            }

            for (int k = 0; k < 10; k++)
            {
                listBox1.Items.Add ($"Posição: {k} MatrizA = {valorInicial[k]} MatrizB = {valorFinal[k]}.");

            }

            
        }

       

    }
}

