﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvenda2
{
    public partial class Form1 : Form
    {
        private double[,]vendas = new double[2, 4];
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            lstVendas.Items.Clear();

            for (int mes = 0; mes < 2; mes++)
            {
                for (int semana = 0; semana < 4; semana++)
                {
                    bool valorValido = false;
                    while (!valorValido)
                    {
                        string entrada = Interaction.InputBox
                            ("Informe o valor vendido(decimal) para o mes e semana");
                        if (entrada == "")

                            vendas[mes, semana] = Convert.ToDouble(entrada);
                        
                        double totalGeral = 0;
                        double totalMes = 0;

                        lstVendas.Items.Add("totais por mes");

                        for (int m = 0; m < 2; m++)
                        {
                            for (int sem = 0; sem < 4; sem++)
                            {
                                totalMes += vendas[m, sem];
                                lstVendas.Items.Add("mes{mes+1}; {totalmes:F2}");

                            }
                        }
                        for (int sem = 0; sem < 4; sem++)
                        {
                            double totalSemana = vendas[0, semana] + vendas[1, semana];
                            lstVendas.Items.Add("semana{semana +1}");

                        }


                    } 

                }
            }
        }

        private void lstVendas_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstVendas.Items.Clear();
        }
    }
}
