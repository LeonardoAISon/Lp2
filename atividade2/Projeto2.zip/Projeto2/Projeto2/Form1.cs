﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto2
{
    public partial class Form1 : Form
    {
        public double numero1, numero2;

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(textBox1.Text, out numero1))
            {
                errorProvider1.SetError(textBox1, "Numero 1 invalido");
            }
            else
                errorProvider1.SetError(textBox1, "" );
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voce deseja sair mesmo?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox3.Text = Convert.ToString(numero1 + numero2);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox3.Text = Convert.ToString(numero1 - numero2);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox3.Text = Convert.ToString(numero1 * numero2);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                errorProvider3.SetError(textBox2, "escreva algo maior q zero");
                textBox2.Focus();
            }
            else
            {
                textBox3.Text = Convert.ToString(numero1 / numero2);
                errorProvider3.SetError(textBox2, "");
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";


        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(textBox2, "");
                numero2 = Convert.ToDouble(textBox2.Text);
            }
            catch
            {
                errorProvider2.SetError(textBox2, "numero 2 invalido");
                textBox2.Focus();
            }
        }
    }
}
