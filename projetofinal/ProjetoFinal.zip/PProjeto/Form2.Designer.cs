﻿namespace PProjeto
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Aluno1 = new System.Windows.Forms.Button();
            this.Aluno2 = new System.Windows.Forms.Button();
            this.Aluno3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Aluno1
            // 
            this.Aluno1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Aluno1.Location = new System.Drawing.Point(1, 395);
            this.Aluno1.Name = "Aluno1";
            this.Aluno1.Size = new System.Drawing.Size(134, 55);
            this.Aluno1.TabIndex = 0;
            this.Aluno1.Text = "Aluno 1";
            this.Aluno1.UseVisualStyleBackColor = true;
            this.Aluno1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Aluno2
            // 
            this.Aluno2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Aluno2.Location = new System.Drawing.Point(339, 380);
            this.Aluno2.Name = "Aluno2";
            this.Aluno2.Size = new System.Drawing.Size(139, 57);
            this.Aluno2.TabIndex = 1;
            this.Aluno2.Text = "Aluno 2";
            this.Aluno2.UseVisualStyleBackColor = true;
            this.Aluno2.Click += new System.EventHandler(this.Aluno2_Click);
            // 
            // Aluno3
            // 
            this.Aluno3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Aluno3.Location = new System.Drawing.Point(661, 393);
            this.Aluno3.Name = "Aluno3";
            this.Aluno3.Size = new System.Drawing.Size(139, 57);
            this.Aluno3.TabIndex = 2;
            this.Aluno3.Text = "Aluno 3";
            this.Aluno3.UseVisualStyleBackColor = true;
            this.Aluno3.Click += new System.EventHandler(this.Aluno3_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label1.Location = new System.Drawing.Point(272, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(300, 50);
            this.label1.TabIndex = 3;
            this.label1.Text = "Aplicação Desenvolvida Por:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PProjeto.Properties.Resources._55709957_pa_coluna_do_noblat_os_irmaos_metralha;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Aluno3);
            this.Controls.Add(this.Aluno2);
            this.Controls.Add(this.Aluno1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Aluno1;
        private System.Windows.Forms.Button Aluno2;
        private System.Windows.Forms.Button Aluno3;
        private System.Windows.Forms.Label label1;
    }
}